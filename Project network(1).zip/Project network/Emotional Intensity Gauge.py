import streamlit as st
import plotly.graph_objects as go

def emotional_gauge(value, title="Emotion Intensity"):
    # กำหนดสีตามระดับ (Logic ของ Mind-Wall)
    bar_color = "red" if value >= 0.8 else "royalblue"
    
    fig = go.Figure(go.Indicator(
        mode = "gauge+number",
        value = value,
        domain = {'x': [0, 1], 'y': [0, 1]},
        title = {'text': title, 'font': {'size': 24}},
        gauge = {
            'axis': {'range': [0, 1], 'tickwidth': 1},
            'bar': {'color': bar_color},
            'bgcolor': "white",
            'borderwidth': 2,
            'bordercolor': "gray",
            'steps': [
                {'range': [0, 0.5], 'color': '#d1f2eb'}, # Low
                {'range': [0.5, 0.8], 'color': '#fcf3cf'}, # Medium
                {'range': [0.8, 1], 'color': '#fadbd8'}  # High (Trauma Zone)
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': 0.8 # จุดที่ Mind-Wall จะเริ่มทำงาน
            }
        }
    ))
    
    fig.update_layout(height=400)
    return fig

# --- ส่วนการแสดงผลบน Dashboard ---
st.title("🌐 OSF Biometric Monitoring")

# จำลองการปรับค่าอารมณ์ (ในโปรเจ็คจริงจะดึงค่าจากฐานข้อมูล)
intensity = st.slider("จำลองระดับอารมณ์จาก Bio-Interface", 0.0, 1.0, 0.5)

# แสดงเข็มไมล์
st.plotly_chart(emotional_gauge(intensity, "Current Emotional Level"), use_container_width=True)

# แสดงสถานะ Mind-Wall
if intensity >= 0.8:
    st.error("⚠️ MIND-WALL ACTIVATED: Trauma Detected! Packet Dropped.")
else:
    st.success("✅ STATUS: Stable Connection")